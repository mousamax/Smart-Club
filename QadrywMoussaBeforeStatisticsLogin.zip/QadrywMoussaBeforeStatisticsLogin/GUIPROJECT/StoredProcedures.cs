﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUIPROJECT
{
    class StoredProcedures
    {
        public static string GetEmployees = "GetEmployeeInfo";
        public static string GetEmployeeFromSSN = "GetEmployeeFromSSN";
        public static string AdjustSalary = "AdjustSalary";
        public static string AddEvents = "AddEvents";
        public static string ShowAllEvents = "ShowAllEvents";
        public static string InsertEmployee = "InsertEmployee";
        public static string RemoveEmployee = "RemoveEmployee";
        public static string AddActivity = "AddActivity";
    }
}
