﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Threading.Tasks;
using Dapper;

namespace GUIPROJECT
{
    public class EMPController
    {
        DBManager dbMan;
        public EMPController()
        {
            dbMan = new DBManager();
        }
        
        public void TerminateConnection()
        {
            dbMan.CloseConnection();
        }
       /* public int AddEvent(int Event_id, string name, string Place, string Date, int Likes, int fees, int member_id)
        {
                            /*
                             @Event_id INT  ,
                  @Name VARCHAR (55) ,
                  @Place VARCHAR (70),
                  @Date DATE ,
                  @Likes INT ,
                  @Fees INT ,
                  @Member_ID INT */
           /*
            string Storedprocedure = StoredProcedures.AddEvents;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@Event_id", Event_id);
            Parameters.Add("@Name", name);
            Parameters.Add("@Place", Place);
            Parameters.Add("@Date", Date);
            Parameters.Add("@Likes", Likes);
            Parameters.Add("@Fees", fees);
            Parameters.Add("@Member_ID", member_id);


            return dbMan.ExecuteNonQuery(Storedprocedure, Parameters);



        }*/
        public int AddActivity(string Name, string place)
        {
            string storedprocedure = StoredProcedures.AddActivity;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            //Parameters.Add("@ID", ID);
            Parameters.Add("@Name", Name);
            Parameters.Add("@Place", place);
            return dbMan.ExecuteNonQuery(storedprocedure, Parameters);

        }
        public int RemoveActivity(string name)
        {
            string query = "delete from Activites where Name='" + name + "'";
            return dbMan.ExecuteNonQuery(name);
        }
        public DataTable ShowAllActivities()
        {
            string Query = "Select * from Activites";
            return dbMan.ExecuteReader(Query);
        }
        //----------------------------------------- Moussa ------------------------------------------//
        public int Insert(int SSN, string FName, string Minit, string LName, string Sex, int Salary, int Super_SSN, int Dno)
        {
            string query = "INSERT INTO Employee (SSN, FName,Minit,LName,Sex,Salary,Super_SSN,Dno) " +
                            "Values (" + SSN + ",'" + FName + "','" + Minit + "','" + LName + "','" + Sex + "'," + Salary + "," + Super_SSN + "," + Dno + ");";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable SelectAllEmp()
        {
            string query = "SELECT * FROM Employee;";
            return dbMan.ExecuteReader(query);
        }
        public int RemoveEmployee(int ssn)
        {
            string storedprocedure = StoredProcedures.RemoveEmployee;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@SSN", ssn);
            return dbMan.ExecuteNonQuery(storedprocedure, Parameters);

        }
        public int Update_Salary(int SSN, int salary)
        {
            string query = "Update Employee set Salary="+ salary +" where SSN = " + SSN + ";";
            return dbMan.ExecuteNonQuery(query);
        }
        //----------------------------------------- Login ------------------------------------------//
        public object GetType(string username, string pass)
        {
            string query = "select Type from Accounts where Username='"+username+ "' AND Password='"+pass+"';";
            return dbMan.ExecuteScalar(query);
        }
        public List<Employee> GetEmployee(string username)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(@"Data Source=localhost;Initial Catalog=Smart_Club;Integrated Security=True"))
            {
                //var output = connection.Query<users>($"select * from users where User_name = '{username}'").ToList();
                //------------------------------it's more secure to use Stored Procedure-------------------------//
                var output = connection.Query<Employee>("dbo.GetEmployeeByUsername @Username", new { Username = username}).ToList();
                return output;
            }
        }
        public List<Members> GetMember(string username)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(@"Data Source=localhost;Initial Catalog=Smart_Club;Integrated Security=True"))
            {
                //var output = connection.Query<users>($"select * from users where User_name = '{username}'").ToList();
                //------------------------------it's more secure to use Stored Procedure-------------------------//
                var output = connection.Query<Members>("dbo.GetMemberByUsername @Username", new { Username = username }).ToList();
                return output;
            }
        }
        // -------------------------- Not Used -------------------------------//
        public DataTable SelectDepNum()
        {
            string query= "SELECT Dnumber, Dname FROM Department;";
            return dbMan.ExecuteReader(query);
        }
        public DataTable SelectDepLoc()
        {
            string query = "SELECT DISTINCT Dlocation FROM Dept_Locations;";
            return dbMan.ExecuteReader(query);
        }

        public DataTable SelectProject(string location)
        {
            string query = "SELECT Pname,Dname FROM Department D, Project P, Dept_Locations L"
             +" where P.Dnum=D.Dnumber and L.Dnumber=D.Dnumber and L.Dlocation='"+location+"';"; 
            
            return dbMan.ExecuteReader(query);
        }
        public int InsertDepartment(string Dname, int Dnumber, int Mgr_SSN, string Mgr_Start_Date)
        {
            string query = "INSERT INTO Department (Dname, Dnumber, Mgr_SSN, Mgr_Start_Date)" +
                            "Values ('" + Dname + "'," + Dnumber + ",'" + Mgr_SSN + "','" + Mgr_Start_Date + "');";
            return dbMan.ExecuteNonQuery(query);
        }
        //9-Get maximum, minimum and average salary for employees
        public object Get_Max_Salary()
        {
            string query = "select MAX(Salary) from Employee;";
            return dbMan.ExecuteScalar(query);
        }
        public object Get_Min_Salary()
        {
            string query = "select MIN(Salary) from Employee;";
            return dbMan.ExecuteScalar(query);
        }
        public object Get_AVG_Salary()
        {
            string query = "select AVG(Salary) from Employee;";
            return dbMan.ExecuteScalar(query);
        }

    }
}
