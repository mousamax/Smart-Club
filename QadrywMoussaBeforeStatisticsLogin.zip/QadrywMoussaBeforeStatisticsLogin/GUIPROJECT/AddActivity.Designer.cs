﻿
namespace GUIPROJECT
{
    partial class Activity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.activityname = new System.Windows.Forms.TextBox();
            this.Place = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ShowActivity = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.AddActivity = new System.Windows.Forms.GroupBox();
            this.RemoveActivity = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.activitesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smart_ClubDataSet = new GUIPROJECT.Smart_ClubDataSet();
            this.activitesTableAdapter = new GUIPROJECT.Smart_ClubDataSetTableAdapters.ActivitesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.AddActivity.SuspendLayout();
            this.RemoveActivity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activitesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smart_ClubDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 110);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Place";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(85, 183);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 28);
            this.button1.TabIndex = 2;
            this.button1.Text = "Add Activity";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // activityname
            // 
            this.activityname.Location = new System.Drawing.Point(85, 20);
            this.activityname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.activityname.Name = "activityname";
            this.activityname.Size = new System.Drawing.Size(76, 20);
            this.activityname.TabIndex = 3;
            this.activityname.TextChanged += new System.EventHandler(this.Name_TextChanged);
            // 
            // Place
            // 
            this.Place.Location = new System.Drawing.Point(85, 110);
            this.Place.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Place.Name = "Place";
            this.Place.Size = new System.Drawing.Size(76, 20);
            this.Place.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(271, 28);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(180, 122);
            this.dataGridView1.TabIndex = 5;
            // 
            // ShowActivity
            // 
            this.ShowActivity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowActivity.Location = new System.Drawing.Point(311, 191);
            this.ShowActivity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ShowActivity.Name = "ShowActivity";
            this.ShowActivity.Size = new System.Drawing.Size(88, 28);
            this.ShowActivity.TabIndex = 6;
            this.ShowActivity.Text = "Show Activity";
            this.ShowActivity.UseVisualStyleBackColor = true;
            this.ShowActivity.Click += new System.EventHandler(this.ShowActivity_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(85, 129);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 28);
            this.button2.TabIndex = 7;
            this.button2.Text = "Remove Activity";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // AddActivity
            // 
            this.AddActivity.Controls.Add(this.Place);
            this.AddActivity.Controls.Add(this.activityname);
            this.AddActivity.Controls.Add(this.button1);
            this.AddActivity.Controls.Add(this.label2);
            this.AddActivity.Controls.Add(this.label1);
            this.AddActivity.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.AddActivity.Location = new System.Drawing.Point(13, 8);
            this.AddActivity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AddActivity.Name = "AddActivity";
            this.AddActivity.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AddActivity.Size = new System.Drawing.Size(214, 219);
            this.AddActivity.TabIndex = 8;
            this.AddActivity.TabStop = false;
            this.AddActivity.Text = "Add Activity";
            // 
            // RemoveActivity
            // 
            this.RemoveActivity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.RemoveActivity.Controls.Add(this.label3);
            this.RemoveActivity.Controls.Add(this.comboBox1);
            this.RemoveActivity.Controls.Add(this.button2);
            this.RemoveActivity.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.RemoveActivity.Location = new System.Drawing.Point(13, 243);
            this.RemoveActivity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RemoveActivity.Name = "RemoveActivity";
            this.RemoveActivity.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RemoveActivity.Size = new System.Drawing.Size(214, 184);
            this.RemoveActivity.TabIndex = 9;
            this.RemoveActivity.TabStop = false;
            this.RemoveActivity.Text = "Remove Activity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Activities";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.activitesBindingSource;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(85, 24);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(99, 21);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.Text = "System.Data.DataViewManagerListItemTypeDescriptor";
            // 
            // activitesBindingSource
            // 
            this.activitesBindingSource.DataMember = "Activites";
            this.activitesBindingSource.DataSource = this.smart_ClubDataSet;
            // 
            // smart_ClubDataSet
            // 
            this.smart_ClubDataSet.DataSetName = "Smart_ClubDataSet";
            this.smart_ClubDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // activitesTableAdapter
            // 
            this.activitesTableAdapter.ClearBeforeFill = true;
            // 
            // Activity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(506, 457);
            this.Controls.Add(this.RemoveActivity);
            this.Controls.Add(this.AddActivity);
            this.Controls.Add(this.ShowActivity);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Activity";
            this.Text = "Activity";
            this.Load += new System.EventHandler(this.Activity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.AddActivity.ResumeLayout(false);
            this.AddActivity.PerformLayout();
            this.RemoveActivity.ResumeLayout(false);
            this.RemoveActivity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activitesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smart_ClubDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox activityname;
        private System.Windows.Forms.TextBox Place;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ShowActivity;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox AddActivity;
        private System.Windows.Forms.GroupBox RemoveActivity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private Smart_ClubDataSet smart_ClubDataSet;
        private System.Windows.Forms.BindingSource activitesBindingSource;
        private Smart_ClubDataSetTableAdapters.ActivitesTableAdapter activitesTableAdapter;
    }
}