﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIPROJECT
{
    public partial class LOGIN : Form
    {
        EMPController empcontroller;
        public LOGIN()
        {
            InitializeComponent();
            loginErrorlabel.Text = "";
        }

        private void LOGIN_Load(object sender, EventArgs e)
        {
            empcontroller = new EMPController();
        }

        private void Loginbutton1_Click(object sender, EventArgs e)
        {
            List<Members> members = new List<Members>();
            List<Employee> employees = new List<Employee>();

            if (empcontroller.GetType(username_textBox.Text, password_textBox.Text) == null)
            {
                loginErrorlabel.Text = "Incorrect User name OR Password";
                return;
            }
            string type = empcontroller.GetType(username_textBox.Text, password_textBox.Text).ToString();
            if (type == "E")
            {
                employees = empcontroller.GetEmployee(username_textBox.Text);
                Employee.LoggedIn = employees[0];
                loginErrorlabel.Text = " ";
                EmployeeDashboard f = new EmployeeDashboard();
                f.Show();
            }
            else
            {
                members = empcontroller.GetMember(username_textBox.Text);
                Members.LoggedIn = members[0];
                loginErrorlabel.Text = " ";
                MemberDashboard f = new MemberDashboard();
                f.Show();
            }
        }

        private void showPasscheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (showPasscheckBox.Checked)
            {
                password_textBox.UseSystemPasswordChar = false;
            }
            else
            {
                password_textBox.UseSystemPasswordChar = true;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            GuestDashboard f = new GuestDashboard();
            f.Show();
        }
    }
}
