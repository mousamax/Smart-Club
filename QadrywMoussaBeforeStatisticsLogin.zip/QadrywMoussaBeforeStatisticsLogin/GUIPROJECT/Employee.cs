﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUIPROJECT
{
    public class Employee
    {
        public int SSN { get; set; }
        public string Fname { get; set; }
        public string Minit { get; set; }
        public string Lname { get; set; }
        public int Salary { get; set; }
        public string Sex { get; set; }
        public int Super_SSN { get; set; }
        public string Username { get; set; }
        public int DNO { get; set; }

        public static Employee LoggedIn { get; set; } // Use it to get loggin Employee info
    }
}
