﻿using DBapplication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIPROJECT
{
    public partial class Requests : Form
    {
        MemberController Membercontroller;
        public Requests()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void testform_Load(object sender, EventArgs e)
        {
            Membercontroller = new MemberController();
            //------------ Show Pending Members ---------------//
            DataTable dt = Membercontroller.SelectPendingMembers();
            PendingMembersdataGridView.DataSource = dt;
            PendingMembersdataGridView.Refresh();
            //-------------------------------------------------//
            datelabel.Text = DateTime.Now.ToString("yyyy-MM-dd");
            //------------ Show Pending Events ---------------//
            dt = Membercontroller.SelectPendingEvents();
            PendingEventsdataGridView.DataSource = dt;
            PendingEventsdataGridView.Refresh();
        }
        private void button4_Click_1(object sender, EventArgs e)
        {
            if (MemberIDtextBox.Text == "" || membershipPricetextBox.Text == "")//validation part
            {
                MessageBox.Show("Please, insert all values");
            }
            else
            {
                StringBuilder err = new StringBuilder();
                Object ID = ValidationClass.isPositiveInteger(MemberIDtextBox.Text, err);
                Object membershipPrice = ValidationClass.isPositiveInteger(membershipPricetextBox.Text, err);
                if (ID == null || membershipPrice == null)
                {
                    MessageBox.Show("Some inputs has incorrect values " + err.ToString());
                }
                else
                {
                    int result = Membercontroller.Accept_Membership((int)membershipPrice, (int)ID);
                    if (result == 0)
                    {
                        MessageBox.Show("The Member enrollment failed");
                    }
                    else
                    {
                        MessageBox.Show("Member Accepted successfully!");
                        //------------ Refresh Pending Members ---------------//
                        DataTable dt = Membercontroller.SelectPendingMembers();
                        PendingMembersdataGridView.DataSource = dt;
                        PendingMembersdataGridView.Refresh();
                        //-------------------------------------------------//
                    }
                }
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (EventIDtextBox.Text == "")//validation part
            {
                MessageBox.Show("Please, insert all values");
            }
            else
            {
                StringBuilder err = new StringBuilder();
                Object ID = ValidationClass.isPositiveInteger(EventIDtextBox.Text, err);
                if (ID == null)
                {
                    MessageBox.Show("Some inputs has incorrect values " + err.ToString());
                }
                else
                {
                    int result = Membercontroller.Confirm_Event((int)ID);
                    if (result == 0)
                    {
                        MessageBox.Show("Confirmation failed");
                    }
                    else
                    {
                        MessageBox.Show("Event Confirmed successfully!");
                        //------------ Show Pending Events ---------------//
                        DataTable dt = Membercontroller.SelectPendingEvents();
                        PendingEventsdataGridView.DataSource = dt;
                        PendingEventsdataGridView.Refresh();
                        //-------------------------------------------------//
                    }
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        
    }   }

