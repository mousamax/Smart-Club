﻿namespace GUIPROJECT
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.leftallpanel = new System.Windows.Forms.Panel();
            this.Exit = new System.Windows.Forms.Button();
            this.Help = new System.Windows.Forms.Button();
            this.Signup = new System.Windows.Forms.Button();
            this.Login = new System.Windows.Forms.Button();
            this.ThirdPanel = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.ThirdSubButton = new System.Windows.Forms.Button();
            this.SecondPanel = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.SecondSubButton = new System.Windows.Forms.Button();
            this.FirstPanel = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.Requestsbutton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.FirstSubmenubutton = new System.Windows.Forms.Button();
            this.panelLOGO = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelchildform = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.leftallpanel.SuspendLayout();
            this.ThirdPanel.SuspendLayout();
            this.SecondPanel.SuspendLayout();
            this.FirstPanel.SuspendLayout();
            this.panelLOGO.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelchildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // leftallpanel
            // 
            this.leftallpanel.AutoScroll = true;
            this.leftallpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.leftallpanel.Controls.Add(this.Exit);
            this.leftallpanel.Controls.Add(this.Help);
            this.leftallpanel.Controls.Add(this.Signup);
            this.leftallpanel.Controls.Add(this.Login);
            this.leftallpanel.Controls.Add(this.ThirdPanel);
            this.leftallpanel.Controls.Add(this.ThirdSubButton);
            this.leftallpanel.Controls.Add(this.SecondPanel);
            this.leftallpanel.Controls.Add(this.SecondSubButton);
            this.leftallpanel.Controls.Add(this.FirstPanel);
            this.leftallpanel.Controls.Add(this.FirstSubmenubutton);
            this.leftallpanel.Controls.Add(this.panelLOGO);
            this.leftallpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftallpanel.Location = new System.Drawing.Point(0, 0);
            this.leftallpanel.Name = "leftallpanel";
            this.leftallpanel.Size = new System.Drawing.Size(241, 610);
            this.leftallpanel.TabIndex = 0;
            // 
            // Exit
            // 
            this.Exit.Dock = System.Windows.Forms.DockStyle.Top;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.ForeColor = System.Drawing.Color.Gainsboro;
            this.Exit.Location = new System.Drawing.Point(0, 715);
            this.Exit.Name = "Exit";
            this.Exit.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.Exit.Size = new System.Drawing.Size(224, 45);
            this.Exit.TabIndex = 11;
            this.Exit.Text = "Exit";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Help
            // 
            this.Help.Dock = System.Windows.Forms.DockStyle.Top;
            this.Help.FlatAppearance.BorderSize = 0;
            this.Help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Help.ForeColor = System.Drawing.Color.Gainsboro;
            this.Help.Location = new System.Drawing.Point(0, 670);
            this.Help.Name = "Help";
            this.Help.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.Help.Size = new System.Drawing.Size(224, 45);
            this.Help.TabIndex = 10;
            this.Help.Text = "Help";
            this.Help.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Help.UseVisualStyleBackColor = true;
            // 
            // Signup
            // 
            this.Signup.Dock = System.Windows.Forms.DockStyle.Top;
            this.Signup.FlatAppearance.BorderSize = 0;
            this.Signup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signup.ForeColor = System.Drawing.Color.Gainsboro;
            this.Signup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Signup.Location = new System.Drawing.Point(0, 625);
            this.Signup.Name = "Signup";
            this.Signup.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.Signup.Size = new System.Drawing.Size(224, 45);
            this.Signup.TabIndex = 9;
            this.Signup.Text = "Signup";
            this.Signup.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Signup.UseVisualStyleBackColor = true;
            // 
            // Login
            // 
            this.Login.Dock = System.Windows.Forms.DockStyle.Top;
            this.Login.FlatAppearance.BorderSize = 0;
            this.Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login.ForeColor = System.Drawing.Color.Gainsboro;
            this.Login.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Login.Location = new System.Drawing.Point(0, 580);
            this.Login.Name = "Login";
            this.Login.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.Login.Size = new System.Drawing.Size(224, 45);
            this.Login.TabIndex = 7;
            this.Login.Text = "Login ";
            this.Login.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // ThirdPanel
            // 
            this.ThirdPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.ThirdPanel.Controls.Add(this.button9);
            this.ThirdPanel.Controls.Add(this.button10);
            this.ThirdPanel.Controls.Add(this.button11);
            this.ThirdPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.ThirdPanel.Location = new System.Drawing.Point(0, 462);
            this.ThirdPanel.Name = "ThirdPanel";
            this.ThirdPanel.Size = new System.Drawing.Size(224, 118);
            this.ThirdPanel.TabIndex = 6;
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.LightGray;
            this.button9.Location = new System.Drawing.Point(0, 80);
            this.button9.Name = "button9";
            this.button9.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button9.Size = new System.Drawing.Size(224, 35);
            this.button9.TabIndex = 2;
            this.button9.Text = "button9";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Top;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.Color.LightGray;
            this.button10.Location = new System.Drawing.Point(0, 40);
            this.button10.Name = "button10";
            this.button10.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button10.Size = new System.Drawing.Size(224, 40);
            this.button10.TabIndex = 1;
            this.button10.Text = "button10";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Dock = System.Windows.Forms.DockStyle.Top;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.Color.LightGray;
            this.button11.Location = new System.Drawing.Point(0, 0);
            this.button11.Name = "button11";
            this.button11.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button11.Size = new System.Drawing.Size(224, 40);
            this.button11.TabIndex = 0;
            this.button11.Text = "button11";
            this.button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // ThirdSubButton
            // 
            this.ThirdSubButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.ThirdSubButton.FlatAppearance.BorderSize = 0;
            this.ThirdSubButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ThirdSubButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.ThirdSubButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ThirdSubButton.Location = new System.Drawing.Point(0, 417);
            this.ThirdSubButton.Name = "ThirdSubButton";
            this.ThirdSubButton.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.ThirdSubButton.Size = new System.Drawing.Size(224, 45);
            this.ThirdSubButton.TabIndex = 5;
            this.ThirdSubButton.Text = "Third";
            this.ThirdSubButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ThirdSubButton.UseVisualStyleBackColor = true;
            this.ThirdSubButton.Click += new System.EventHandler(this.ThirdSubButton_Click);
            // 
            // SecondPanel
            // 
            this.SecondPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.SecondPanel.Controls.Add(this.button5);
            this.SecondPanel.Controls.Add(this.button6);
            this.SecondPanel.Controls.Add(this.button7);
            this.SecondPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.SecondPanel.Location = new System.Drawing.Point(0, 299);
            this.SecondPanel.Name = "SecondPanel";
            this.SecondPanel.Size = new System.Drawing.Size(224, 118);
            this.SecondPanel.TabIndex = 4;
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.LightGray;
            this.button5.Location = new System.Drawing.Point(0, 80);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(224, 35);
            this.button5.TabIndex = 2;
            this.button5.Text = "button5";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.LightGray;
            this.button6.Location = new System.Drawing.Point(0, 40);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(224, 40);
            this.button6.TabIndex = 1;
            this.button6.Text = "button6";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.LightGray;
            this.button7.Location = new System.Drawing.Point(0, 0);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(224, 40);
            this.button7.TabIndex = 0;
            this.button7.Text = "button7";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // SecondSubButton
            // 
            this.SecondSubButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.SecondSubButton.FlatAppearance.BorderSize = 0;
            this.SecondSubButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SecondSubButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.SecondSubButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SecondSubButton.Location = new System.Drawing.Point(0, 254);
            this.SecondSubButton.Name = "SecondSubButton";
            this.SecondSubButton.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.SecondSubButton.Size = new System.Drawing.Size(224, 45);
            this.SecondSubButton.TabIndex = 3;
            this.SecondSubButton.Text = "Second";
            this.SecondSubButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SecondSubButton.UseVisualStyleBackColor = true;
            this.SecondSubButton.Click += new System.EventHandler(this.SecondSubButton_Click);
            // 
            // FirstPanel
            // 
            this.FirstPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.FirstPanel.Controls.Add(this.button4);
            this.FirstPanel.Controls.Add(this.Requestsbutton);
            this.FirstPanel.Controls.Add(this.button2);
            this.FirstPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.FirstPanel.Location = new System.Drawing.Point(0, 136);
            this.FirstPanel.Name = "FirstPanel";
            this.FirstPanel.Size = new System.Drawing.Size(224, 118);
            this.FirstPanel.TabIndex = 2;
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.LightGray;
            this.button4.Location = new System.Drawing.Point(0, 80);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button4.Size = new System.Drawing.Size(224, 35);
            this.button4.TabIndex = 2;
            this.button4.Text = "Revenue";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Requestsbutton
            // 
            this.Requestsbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Requestsbutton.FlatAppearance.BorderSize = 0;
            this.Requestsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Requestsbutton.ForeColor = System.Drawing.Color.LightGray;
            this.Requestsbutton.Location = new System.Drawing.Point(0, 40);
            this.Requestsbutton.Name = "Requestsbutton";
            this.Requestsbutton.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.Requestsbutton.Size = new System.Drawing.Size(224, 40);
            this.Requestsbutton.TabIndex = 1;
            this.Requestsbutton.Text = "Requests";
            this.Requestsbutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Requestsbutton.UseVisualStyleBackColor = true;
            this.Requestsbutton.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.LightGray;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(224, 40);
            this.button2.TabIndex = 0;
            this.button2.Text = "Employees";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FirstSubmenubutton
            // 
            this.FirstSubmenubutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.FirstSubmenubutton.FlatAppearance.BorderSize = 0;
            this.FirstSubmenubutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FirstSubmenubutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.FirstSubmenubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FirstSubmenubutton.Location = new System.Drawing.Point(0, 91);
            this.FirstSubmenubutton.Name = "FirstSubmenubutton";
            this.FirstSubmenubutton.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.FirstSubmenubutton.Size = new System.Drawing.Size(224, 45);
            this.FirstSubmenubutton.TabIndex = 1;
            this.FirstSubmenubutton.Text = "Manager";
            this.FirstSubmenubutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FirstSubmenubutton.UseVisualStyleBackColor = true;
            this.FirstSubmenubutton.Click += new System.EventHandler(this.FirstSubmenubutton_Click);
            // 
            // panelLOGO
            // 
            this.panelLOGO.Controls.Add(this.pictureBox2);
            this.panelLOGO.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLOGO.Location = new System.Drawing.Point(0, 0);
            this.panelLOGO.Name = "panelLOGO";
            this.panelLOGO.Size = new System.Drawing.Size(224, 91);
            this.panelLOGO.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(44, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(150, 109);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panelchildform
            // 
            this.panelchildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panelchildform.Controls.Add(this.pictureBox1);
            this.panelchildform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelchildform.Location = new System.Drawing.Point(241, 0);
            this.panelchildform.Name = "panelchildform";
            this.panelchildform.Size = new System.Drawing.Size(693, 610);
            this.panelchildform.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(148, 127);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(424, 335);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 610);
            this.Controls.Add(this.panelchildform);
            this.Controls.Add(this.leftallpanel);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MinimumSize = new System.Drawing.Size(950, 600);
            this.Name = "Dashboard";
            this.Text = "SmartClub";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.leftallpanel.ResumeLayout(false);
            this.ThirdPanel.ResumeLayout(false);
            this.SecondPanel.ResumeLayout(false);
            this.FirstPanel.ResumeLayout(false);
            this.panelLOGO.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelchildform.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel leftallpanel;
        private System.Windows.Forms.Panel FirstPanel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button FirstSubmenubutton;
        private System.Windows.Forms.Panel panelLOGO;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Requestsbutton;
        private System.Windows.Forms.Panel SecondPanel;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button SecondSubButton;
        private System.Windows.Forms.Button Signup;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Panel ThirdPanel;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button ThirdSubButton;
        private System.Windows.Forms.Button Help;
        private System.Windows.Forms.Panel panelchildform;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.PictureBox pictureBox2;

    }
}

