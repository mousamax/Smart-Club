﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIPROJECT
{
    
    public partial class Activity : Form
    {
        EMPController empcontroller;
        public Activity()
        {
            InitializeComponent();

            DataTable dt = empcontroller.ShowAllActivities();
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Name";
        }

        private void Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (activityname.Text == "" || Place.Text == "")
            {
                MessageBox.Show("Please insert all Values");
            }
            //No validation was tested will be implemented Later

            else if (!(activityname.Text.All(c => Char.IsLetter(c) || c.Equals('_'))))
            {
                MessageBox.Show("Please Remove Any Numbers or Special CHaracters!");
            }
            else
            {
                int r = empcontroller.AddActivity(activityname.Text, Place.Text);
                if (r > 0)
                    MessageBox.Show("Activity inserted successfully");
                else
                    MessageBox.Show("Insertion Failed");
            }
        }

        private void ShowActivity_Click(object sender, EventArgs e)
        {
            DataTable dt = empcontroller.ShowAllActivities();
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void Activity_Load(object sender, EventArgs e)
        {
            empcontroller = new EMPController();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int r = empcontroller.RemoveActivity(comboBox1.Text);
            if (r > 0)
                MessageBox.Show("Activity Removed successfully");
            else
                MessageBox.Show("Remove Failed");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
