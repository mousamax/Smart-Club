﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIPROJECT
{
    public partial class Awards : Form
    {
        EMPController eMPController;
        public Awards()
        {
            InitializeComponent();
            eMPController = new EMPController();
            DataTable teams = eMPController.ShowAllTeams();
            teambox.DataSource = teams;
            teambox.DisplayMember = "ID";
            DataTable awards = eMPController.ShowAllAwards();
            awardbox.DataSource = awards;
            awardbox.DisplayMember = "Name";
            DataTable awards2 = eMPController.ShowAllAwards();
            awardbox2.DataSource = awards2;
            awardbox2.DisplayMember = "Name";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (awardname.Text == "")
            {
                MessageBox.Show("Please insert all Values");
            }
            else if (!(awardname.Text.All(c => Char.IsLetter(c))))
            {
                MessageBox.Show("Please Remove Any Numbers or Special CHaracters!");
            }
            else
            {
                int r = eMPController.AddNewAward(awardname.Text);
                if (r > 0)
                {
                    MessageBox.Show("Awarded inserted successfully");
                    DataTable awards = eMPController.ShowAllAwards();
                    awardbox.DataSource = awards;
                    awardbox.DisplayMember = "Name";
                    DataTable awards2 = eMPController.ShowAllAwards();
                    awardbox2.DataSource = awards2;
                    awardbox2.DisplayMember = "Name";
                }
                else
                    MessageBox.Show("Insertion Failed");
            }
        }

        private void teambox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int r = eMPController.AwardTeam(Convert.ToInt32(awardbox.Text), Convert.ToInt32(teambox.Text));
            if (r > 0)
                MessageBox.Show("Team Awarded  successfully");
            else
                MessageBox.Show("Team Awarding  Failed");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
