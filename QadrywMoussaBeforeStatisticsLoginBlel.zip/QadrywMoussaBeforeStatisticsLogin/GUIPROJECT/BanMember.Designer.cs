﻿
namespace GUIPROJECT
{
    partial class BanMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ban = new System.Windows.Forms.Button();
            this.name = new System.Windows.Forms.ComboBox();
            this.MemberName = new System.Windows.Forms.Label();
            this.MemberSSN = new System.Windows.Forms.Label();
            this.ssn = new System.Windows.Forms.ComboBox();
            this.unban = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ban
            // 
            this.ban.BackColor = System.Drawing.Color.Red;
            this.ban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ban.Location = new System.Drawing.Point(472, 12);
            this.ban.Name = "ban";
            this.ban.Size = new System.Drawing.Size(154, 54);
            this.ban.TabIndex = 0;
            this.ban.Text = "Ban!";
            this.ban.UseVisualStyleBackColor = false;
            this.ban.Click += new System.EventHandler(this.button1_Click);
            // 
            // name
            // 
            this.name.FormattingEnabled = true;
            this.name.Location = new System.Drawing.Point(190, 138);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(121, 24);
            this.name.TabIndex = 1;
            this.name.SelectedIndexChanged += new System.EventHandler(this.name_SelectedIndexChanged);
            // 
            // MemberName
            // 
            this.MemberName.AutoSize = true;
            this.MemberName.BackColor = System.Drawing.Color.Transparent;
            this.MemberName.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.MemberName.Location = new System.Drawing.Point(12, 141);
            this.MemberName.Name = "MemberName";
            this.MemberName.Size = new System.Drawing.Size(100, 17);
            this.MemberName.TabIndex = 2;
            this.MemberName.Text = "Member Name";
            this.MemberName.Click += new System.EventHandler(this.label1_Click);
            // 
            // MemberSSN
            // 
            this.MemberSSN.AutoSize = true;
            this.MemberSSN.BackColor = System.Drawing.Color.Transparent;
            this.MemberSSN.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.MemberSSN.Location = new System.Drawing.Point(12, 36);
            this.MemberSSN.Name = "MemberSSN";
            this.MemberSSN.Size = new System.Drawing.Size(91, 17);
            this.MemberSSN.TabIndex = 3;
            this.MemberSSN.Text = "Member SSN";
            // 
            // ssn
            // 
            this.ssn.FormattingEnabled = true;
            this.ssn.Location = new System.Drawing.Point(190, 33);
            this.ssn.Name = "ssn";
            this.ssn.Size = new System.Drawing.Size(121, 24);
            this.ssn.TabIndex = 4;
            this.ssn.SelectedIndexChanged += new System.EventHandler(this.ssn_SelectedIndexChanged);
            // 
            // unban
            // 
            this.unban.BackColor = System.Drawing.Color.Lime;
            this.unban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unban.Location = new System.Drawing.Point(472, 120);
            this.unban.Name = "unban";
            this.unban.Size = new System.Drawing.Size(154, 54);
            this.unban.TabIndex = 5;
            this.unban.Text = "UnBan!";
            this.unban.UseVisualStyleBackColor = false;
            this.unban.Click += new System.EventHandler(this.unban_Click);
            // 
            // BanMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(675, 563);
            this.Controls.Add(this.unban);
            this.Controls.Add(this.ssn);
            this.Controls.Add(this.MemberSSN);
            this.Controls.Add(this.MemberName);
            this.Controls.Add(this.name);
            this.Controls.Add(this.ban);
            this.Name = "BanMember";
            this.Text = "BanMember";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ban;
        private System.Windows.Forms.ComboBox name;
        private System.Windows.Forms.Label MemberName;
        private System.Windows.Forms.Label MemberSSN;
        private System.Windows.Forms.ComboBox ssn;
        private System.Windows.Forms.Button unban;
    }
}