﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUIPROJECT
{
    public class Members
    {
        public int ID { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public int Age { get; set; }
        public string Sex { get; set; }
        public string Status { get; set; }
        public string Start_Date { get; set; }
        public string End_Date { get; set; }
        public int MemberShip_Price { get; set; }
        public string Username { get; set; }


        public static Members LoggedIn { get; set; }  // Use it to get loggin member info
    }
}
