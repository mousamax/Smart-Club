﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIPROJECT
{
    public partial class BanMember : Form
    {
        EMPController eMPController;
        MemberController memberController;
        public BanMember()
        {
            InitializeComponent();
            eMPController = new EMPController();
            memberController = new MemberController();
            DataTable dt = memberController.ShowAllMembers();
            ssn.DataSource = dt;
            ssn.DisplayMember = "ID";
            DataTable dte = memberController.ShowAllMembers();
            name.DataSource = dte;
            name.DisplayMember = "Fname";


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void name_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dte = memberController.ShowMemberFromID(Convert.ToInt32(ssn.Text));
            name.DataSource = dte;
            name.DisplayMember = "ID";
        }

        private void ssn_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dte = memberController.ShowMemberFromID(Convert.ToInt32(ssn.Text));
            name.DataSource = dte;
            name.DisplayMember = "Fname";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DataTable dt = memberController.CheckIfMemberISUnBanned(Convert.ToInt32(ssn.Text));
            if (dt != null)
                MessageBox.Show("The Member is Already  Banned!");
            else
            {
                int r = eMPController.BanMember(Convert.ToInt32(ssn.Text));
                if (r > 0)
                    MessageBox.Show("Member Banned successfully");
                else
                    MessageBox.Show("Member Banning Failed ");
            }
        }

        private void unban_Click(object sender, EventArgs e)
        {
            DataTable dt = memberController.CheckIfMemberISUnBanned(Convert.ToInt32(ssn.Text));
            if (dt == null)
                MessageBox.Show("The Member is Already Not Banned!");
            else
            {
                int r = eMPController.UnBanMember(Convert.ToInt32(ssn.Text));
                if (r > 0)
                    MessageBox.Show("Member UnBanned successfully");
                else
                    MessageBox.Show("Member UnBanning Failed ");
            }
        }

        private void BanMember_Load(object sender, EventArgs e)
        {

        }
    }
}
