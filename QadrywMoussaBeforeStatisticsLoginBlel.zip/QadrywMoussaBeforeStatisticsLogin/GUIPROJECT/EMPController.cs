﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Threading.Tasks;
using Dapper;

namespace GUIPROJECT
{
    public class EMPController
    {

        //New DATA MEMBERRRRR
        public static int ParkingFees { get; set; }
        DBManager dbMan;
        public EMPController()
        {
            dbMan = new DBManager();
        }
        
        public void TerminateConnection()
        {
            dbMan.CloseConnection();
        }
        /* public int AddEvent(int Event_id, string name, string Place, string Date, int Likes, int fees, int member_id)
         {
                             /*
                              @Event_id INT  ,
                   @Name VARCHAR (55) ,
                   @Place VARCHAR (70),
                   @Date DATE ,
                   @Likes INT ,
                   @Fees INT ,
                   @Member_ID INT */
        /*
         string Storedprocedure = StoredProcedures.AddEvents;
         Dictionary<string, object> Parameters = new Dictionary<string, object>();
         Parameters.Add("@Event_id", Event_id);
         Parameters.Add("@Name", name);
         Parameters.Add("@Place", Place);
         Parameters.Add("@Date", Date);
         Parameters.Add("@Likes", Likes);
         Parameters.Add("@Fees", fees);
         Parameters.Add("@Member_ID", member_id);


         return dbMan.ExecuteNonQuery(Storedprocedure, Parameters);



     }*/

        //---------------------------Qadoura----------------------------------------
      
        public int AddActivity(string Name, string place)
        {
            string storedprocedure = StoredProcedures.AddActivity;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            //Parameters.Add("@ID", ID);
            Parameters.Add("@Name", Name);
            Parameters.Add("@Place", place);
            return dbMan.ExecuteNonQuery(storedprocedure, Parameters);

        }

        public DataTable SelectAllEmp()
        {
            string query = "SELECT * FROM Employee;";
            return dbMan.ExecuteReader(query);
        }
        public int RemoveActivity(string name)
        {
            string query = "delete from Activites where Name='" + name + "'";
            return dbMan.ExecuteNonQuery(name);
        }
        public DataTable ShowAllActivities()
        {
            string Query = "Select * from Activites";
            return dbMan.ExecuteReader(Query);
        }
        public int AddNewAward(string x)
        {
            string query = "Insert into Awards(Name) Values('" + x + "')";
            return dbMan.ExecuteNonQuery(query);
        }
        public int AwardTeam(int awardid, int teamid)
        {
            string query = "Insert into Awards_Teams(Team_ID,Award_ID) values (" + teamid + "," + awardid + ")";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable ShowAllTeams()
        {
            string query = "Select * from Teams";
            return dbMan.ExecuteReader(query);
        }
        public DataTable ShowAllAwards()
        {
            string query = "Select * from Awards";
            return dbMan.ExecuteReader(query);
        }
        public Object ViewParkingStatistics(string From, string To)
        {
            string query = "Select AVG(Fees) from Parking where Start_Date>='" + From + "' and End_Date<'" + To + "'";
            return dbMan.ExecuteScalar(query);
        }

        public int UnBanMember(int ID)
        {
            string query = "Update Members set Status = 'UnBanned' where ID=" + ID + "";
            return dbMan.ExecuteNonQuery(query);
        }
        public int BanMember(int ID)
        {
            string query = "Update Members set Status = 'Banned' where ID=" + ID + "";
            return dbMan.ExecuteNonQuery(query);
        }


        //--------------------------------------------------------------------
        //----------------------------------------- Moussa ------------------------------------------//
        public int Insert(int SSN, string FName, string Minit, string LName, string Sex, int Salary, int Super_SSN, int Dno)
        {
            string query = "INSERT INTO Employee (SSN, FName,Minit,LName,Sex,Salary,Super_SSN,Dno) " +
                            "Values (" + SSN + ",'" + FName + "','" + Minit + "','" + LName + "','" + Sex + "'," + Salary + "," + Super_SSN + "," + Dno + ");";
            return dbMan.ExecuteNonQuery(query);
        }
      
        public int RemoveEmployee(int ssn)
        {
            string storedprocedure = StoredProcedures.RemoveEmployee;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@SSN", ssn);
            return dbMan.ExecuteNonQuery(storedprocedure, Parameters);

        }
        public int Update_Salary(int SSN, int salary)
        {
            string query = "Update Employee set Salary="+ salary +" where SSN = " + SSN + ";";
            return dbMan.ExecuteNonQuery(query);
        }
        //----------------------------------------- Login ------------------------------------------//
        public object GetType(string username, string pass)
        {
            string query = "select Type from Accounts where Username='"+username+ "' AND Password='"+pass+"';";
            return dbMan.ExecuteScalar(query);
        }
        public List<Employee> GetEmployee(string username)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(@"Data Source=localhost;Initial Catalog=Smart_Club;Integrated Security=True"))
            {
                //var output = connection.Query<users>($"select * from users where User_name = '{username}'").ToList();
                //------------------------------it's more secure to use Stored Procedure-------------------------//
                var output = connection.Query<Employee>("dbo.GetEmployeeByUsername @Username", new { Username = username}).ToList();
                return output;
            }
        }
        public List<Members> GetMember(string username)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(@"Data Source=localhost;Initial Catalog=Smart_Club;Integrated Security=True"))
            {
                //var output = connection.Query<users>($"select * from users where User_name = '{username}'").ToList();
                //------------------------------it's more secure to use Stored Procedure-------------------------//
                var output = connection.Query<Members>("dbo.GetMemberByUsername @Username", new { Username = username }).ToList();
                return output;
            }
        }
        

    }
}
