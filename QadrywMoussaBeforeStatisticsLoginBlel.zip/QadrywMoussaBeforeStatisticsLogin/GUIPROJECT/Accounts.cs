﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUIPROJECT
{
    public class Accounts
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Type { get; set; }

        public static Accounts LoggedIn { get; set; }  // Use it to get loggin Account info
    }
}
