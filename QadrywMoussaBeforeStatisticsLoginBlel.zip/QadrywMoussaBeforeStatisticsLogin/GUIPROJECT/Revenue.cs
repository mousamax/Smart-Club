﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIPROJECT
{
    public partial class Revenue : Form
    {
        EMPController eMPController;
        public Revenue()
        {
            InitializeComponent();
            eMPController = new EMPController();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            revenuee.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Year.Text == "")
            {
                MessageBox.Show("PLease Enter Some Values!");

            }
            else if (!(Year.Text.All(c => Char.IsDigit(c))))
            {
                MessageBox.Show("Please Remove Any Letters from Years!");

            }
            else
            {
                string from = Year.Text + "-01-01";
                int year = Convert.ToInt32(Year.Text);
                year++;
                string to = Convert.ToString(year);
                to = to + "-01-01";


                revenuee.Text = eMPController.ViewParkingStatistics(from, to).ToString();
            }

        }

        private void revenuee_Click(object sender, EventArgs e)
        {

        }

        private void feesbutton_Click(object sender, EventArgs e)
        {
            if (parkingfees.Text == "")
            {
                MessageBox.Show("Please insert all Values");
            }
            else
            {

                StringBuilder err = new StringBuilder();
                Object Fees = ValidationClass.isPositiveInteger(parkingfees.Text, err);
                if (Fees == null)
                {
                    MessageBox.Show("Some inputs has incorrect values " + err.ToString());
                }
                else
                {
                    EMPController.ParkingFees = Convert.ToInt32(parkingfees.Text);
                }
            }
        }

        private void Revenue_Load(object sender, EventArgs e)
        {

        }
    }
}
