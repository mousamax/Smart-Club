﻿
namespace GUIPROJECT
{
    partial class Revenue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Year = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.revenueeLabel = new System.Windows.Forms.Label();
            this.revenuee = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.parkingfees = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.feesbutton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(169, 32);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(100, 22);
            this.Year.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.revenueeLabel);
            this.groupBox1.Controls.Add(this.revenuee);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Year);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(582, 215);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Parking Annual Revenue";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // revenueeLabel
            // 
            this.revenueeLabel.AutoSize = true;
            this.revenueeLabel.Location = new System.Drawing.Point(320, 36);
            this.revenueeLabel.Name = "revenueeLabel";
            this.revenueeLabel.Size = new System.Drawing.Size(65, 17);
            this.revenueeLabel.TabIndex = 4;
            this.revenueeLabel.Text = "Revenue";
            this.revenueeLabel.Click += new System.EventHandler(this.revenuee_Click);
            // 
            // revenuee
            // 
            this.revenuee.Enabled = false;
            this.revenuee.Location = new System.Drawing.Point(420, 32);
            this.revenuee.Name = "revenuee";
            this.revenuee.ReadOnly = true;
            this.revenuee.Size = new System.Drawing.Size(100, 22);
            this.revenuee.TabIndex = 3;
            this.revenuee.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(169, 142);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 2;
            this.button1.Text = "GetRevenue";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Year";
            // 
            // parkingfees
            // 
            this.parkingfees.Location = new System.Drawing.Point(181, 279);
            this.parkingfees.Name = "parkingfees";
            this.parkingfees.Size = new System.Drawing.Size(100, 22);
            this.parkingfees.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Location = new System.Drawing.Point(34, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Parking Fees";
            // 
            // feesbutton
            // 
            this.feesbutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.feesbutton.Location = new System.Drawing.Point(432, 273);
            this.feesbutton.Name = "feesbutton";
            this.feesbutton.Size = new System.Drawing.Size(100, 28);
            this.feesbutton.TabIndex = 4;
            this.feesbutton.Text = "Set Parking Fees";
            this.feesbutton.UseVisualStyleBackColor = true;
            this.feesbutton.Click += new System.EventHandler(this.feesbutton_Click);
            // 
            // Revenue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(675, 563);
            this.Controls.Add(this.feesbutton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.parkingfees);
            this.Controls.Add(this.groupBox1);
            this.Name = "Revenue";
            this.Text = "Revenue";
            this.Load += new System.EventHandler(this.Revenue_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label revenueeLabel;
        private System.Windows.Forms.TextBox revenuee;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox parkingfees;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button feesbutton;
    }
}