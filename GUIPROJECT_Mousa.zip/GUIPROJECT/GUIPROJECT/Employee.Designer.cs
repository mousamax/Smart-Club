﻿namespace GUIPROJECT
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.InsertEmployeepanel = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.LNametextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.insertButton = new System.Windows.Forms.Button();
            this.DnotextBox = new System.Windows.Forms.TextBox();
            this.SSNTextBox = new System.Windows.Forms.TextBox();
            this.superssntextBox = new System.Windows.Forms.TextBox();
            this.FNameTextBox = new System.Windows.Forms.TextBox();
            this.SalarytextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SexcomboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Sexlabel = new System.Windows.Forms.Label();
            this.MinittextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.deleteSSNtextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.InsertEmployeepanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(0, 430);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(677, 94);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(141, 401);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Return";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(222, 401);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkRed;
            this.button3.Location = new System.Drawing.Point(371, 36);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(133, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Fire";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.Location = new System.Drawing.Point(4, 401);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(126, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Show all employees";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Hire Employee";
            // 
            // InsertEmployeepanel
            // 
            this.InsertEmployeepanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InsertEmployeepanel.Controls.Add(this.label14);
            this.InsertEmployeepanel.Controls.Add(this.LNametextBox);
            this.InsertEmployeepanel.Controls.Add(this.label13);
            this.InsertEmployeepanel.Controls.Add(this.insertButton);
            this.InsertEmployeepanel.Controls.Add(this.DnotextBox);
            this.InsertEmployeepanel.Controls.Add(this.SSNTextBox);
            this.InsertEmployeepanel.Controls.Add(this.superssntextBox);
            this.InsertEmployeepanel.Controls.Add(this.FNameTextBox);
            this.InsertEmployeepanel.Controls.Add(this.SalarytextBox);
            this.InsertEmployeepanel.Controls.Add(this.label2);
            this.InsertEmployeepanel.Controls.Add(this.label11);
            this.InsertEmployeepanel.Controls.Add(this.label3);
            this.InsertEmployeepanel.Controls.Add(this.label12);
            this.InsertEmployeepanel.Controls.Add(this.SexcomboBox);
            this.InsertEmployeepanel.Controls.Add(this.label9);
            this.InsertEmployeepanel.Controls.Add(this.Sexlabel);
            this.InsertEmployeepanel.Controls.Add(this.MinittextBox);
            this.InsertEmployeepanel.Controls.Add(this.label10);
            this.InsertEmployeepanel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.InsertEmployeepanel.Location = new System.Drawing.Point(91, 45);
            this.InsertEmployeepanel.Name = "InsertEmployeepanel";
            this.InsertEmployeepanel.Size = new System.Drawing.Size(522, 214);
            this.InsertEmployeepanel.TabIndex = 39;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.label14.Location = new System.Drawing.Point(190, 5);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 18);
            this.label14.TabIndex = 39;
            this.label14.Text = "New Employee";
            // 
            // LNametextBox
            // 
            this.LNametextBox.Location = new System.Drawing.Point(384, 62);
            this.LNametextBox.Name = "LNametextBox";
            this.LNametextBox.Size = new System.Drawing.Size(121, 20);
            this.LNametextBox.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(192, 94);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(27, 13);
            this.label13.TabIndex = 37;
            this.label13.Text = "Dno";
            // 
            // insertButton
            // 
            this.insertButton.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.insertButton.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.insertButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.insertButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertButton.ForeColor = System.Drawing.Color.White;
            this.insertButton.Location = new System.Drawing.Point(372, 181);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(133, 24);
            this.insertButton.TabIndex = 0;
            this.insertButton.Text = "Insert Employee";
            this.insertButton.UseVisualStyleBackColor = false;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
            // 
            // DnotextBox
            // 
            this.DnotextBox.Location = new System.Drawing.Point(227, 91);
            this.DnotextBox.Name = "DnotextBox";
            this.DnotextBox.Size = new System.Drawing.Size(100, 20);
            this.DnotextBox.TabIndex = 36;
            // 
            // SSNTextBox
            // 
            this.SSNTextBox.Location = new System.Drawing.Point(73, 33);
            this.SSNTextBox.Name = "SSNTextBox";
            this.SSNTextBox.Size = new System.Drawing.Size(100, 20);
            this.SSNTextBox.TabIndex = 1;
            // 
            // superssntextBox
            // 
            this.superssntextBox.Location = new System.Drawing.Point(73, 91);
            this.superssntextBox.Name = "superssntextBox";
            this.superssntextBox.Size = new System.Drawing.Size(100, 20);
            this.superssntextBox.TabIndex = 35;
            // 
            // FNameTextBox
            // 
            this.FNameTextBox.Location = new System.Drawing.Point(73, 63);
            this.FNameTextBox.Name = "FNameTextBox";
            this.FNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.FNameTextBox.TabIndex = 2;
            // 
            // SalarytextBox
            // 
            this.SalarytextBox.Location = new System.Drawing.Point(384, 91);
            this.SalarytextBox.Name = "SalarytextBox";
            this.SalarytextBox.Size = new System.Drawing.Size(121, 20);
            this.SalarytextBox.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(8, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "SSN#";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(8, 94);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "Super_SSN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(8, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "FName";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(337, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 31;
            this.label12.Text = "Salary";
            // 
            // SexcomboBox
            // 
            this.SexcomboBox.FormattingEnabled = true;
            this.SexcomboBox.Items.AddRange(new object[] {
            "M",
            "F"});
            this.SexcomboBox.Location = new System.Drawing.Point(384, 124);
            this.SexcomboBox.Name = "SexcomboBox";
            this.SexcomboBox.Size = new System.Drawing.Size(121, 21);
            this.SexcomboBox.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(337, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "LName";
            // 
            // Sexlabel
            // 
            this.Sexlabel.AutoSize = true;
            this.Sexlabel.ForeColor = System.Drawing.Color.White;
            this.Sexlabel.Location = new System.Drawing.Point(337, 124);
            this.Sexlabel.Name = "Sexlabel";
            this.Sexlabel.Size = new System.Drawing.Size(25, 13);
            this.Sexlabel.TabIndex = 27;
            this.Sexlabel.Text = "Sex";
            // 
            // MinittextBox
            // 
            this.MinittextBox.Location = new System.Drawing.Point(227, 59);
            this.MinittextBox.Name = "MinittextBox";
            this.MinittextBox.Size = new System.Drawing.Size(100, 20);
            this.MinittextBox.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(192, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Minit";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.deleteSSNtextBox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Location = new System.Drawing.Point(91, 269);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 84);
            this.panel1.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Brown;
            this.label4.Location = new System.Drawing.Point(191, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 18);
            this.label4.TabIndex = 40;
            this.label4.Text = "Fire Employee";
            // 
            // deleteSSNtextBox
            // 
            this.deleteSSNtextBox.Location = new System.Drawing.Point(74, 41);
            this.deleteSSNtextBox.Name = "deleteSSNtextBox";
            this.deleteSSNtextBox.Size = new System.Drawing.Size(100, 20);
            this.deleteSSNtextBox.TabIndex = 41;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(14, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 42;
            this.label5.Text = "SSN#";
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(677, 524);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.InsertEmployeepanel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Employee";
            this.Text = "testform";
            this.Load += new System.EventHandler(this.Employee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.InsertEmployeepanel.ResumeLayout(false);
            this.InsertEmployeepanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel InsertEmployeepanel;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox LNametextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.TextBox DnotextBox;
        private System.Windows.Forms.TextBox SSNTextBox;
        private System.Windows.Forms.TextBox superssntextBox;
        private System.Windows.Forms.TextBox FNameTextBox;
        private System.Windows.Forms.TextBox SalarytextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox SexcomboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label Sexlabel;
        private System.Windows.Forms.TextBox MinittextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox deleteSSNtextBox;
        private System.Windows.Forms.Label label5;
    }
}